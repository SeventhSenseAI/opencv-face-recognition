# Testing guide

This file should explain how to test the project’s codebase and functionality for quality and reliability. It should include the tools, frameworks, methods, commands, etc. that are used to run and automate tests for the project. This is only for automated tests done by developers.
