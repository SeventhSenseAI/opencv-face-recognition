package ai.seventhsense.opencvfr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
