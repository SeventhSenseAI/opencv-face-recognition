package com.example.faceapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
