package com.example.fintech_seventhsense_facerecognition_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
